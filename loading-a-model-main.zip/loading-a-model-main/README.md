### Loading a Model with THREE.js

See https://youtu.be/Cxd2gYRrz4c
